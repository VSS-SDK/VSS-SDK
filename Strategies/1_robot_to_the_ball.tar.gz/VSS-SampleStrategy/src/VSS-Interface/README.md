# SirSoccer-COM
Communication module from SirSoccer Robots
