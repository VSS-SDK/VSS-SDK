#ifndef _BOOSTS_H_
#define _BOOSTS_H_

#include <boost/program_options.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/make_shared.hpp>

namespace bpo = boost::program_options;

#endif
